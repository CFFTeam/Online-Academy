const courses = [
    {
        _id: "",
        name: "",
        img: "",
        slug: "",
        author: "",
        description: "",
        currency: "",
        price: "",
        sale: "",
        category: "",
        subcategory: "",
        details: "",
        date: "",
        lectures: {
            total: "",
            duration: "",
            sections: [ 
                {
                    _id: "",
                    title: "",
                    total: "",
                    duration: "",
                    lessons: [
                        {
                            _id: "",
                            title: "",
                            resources: "",
                            video: ""
                        }
                    ]
                } 
            ]
        }
    }
];