const promotion = {
  _id: "",
  name: "",
  value: ""
}