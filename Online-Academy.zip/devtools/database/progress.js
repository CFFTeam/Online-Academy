const progressCourse = [
    {
        course_id: "",
        total: 100,
        progress: [
            
        ]        
    }
]