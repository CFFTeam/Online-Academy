const course_details = {
    id: "",
    viewer: 0,
    avg_rating: 0,
    reviews: [
        {
            title: "",
            author: "",
            rating: 0,
            created: ""
        }
    ]
}