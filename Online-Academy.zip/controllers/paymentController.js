export const shoppingCartPage = (req, res) => {
  res.render("payment/shoppingCart")
};