export const wishlistPage = (req, res) => {
  res.render("wishlist/wishlist")
};